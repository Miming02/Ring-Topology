/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package ringtopologyproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;

/**
 *
 * @author user
 */
public class NewJPanel extends javax.swing.JPanel {
    TokenHandler tokenH;
    /**
     * Creates new form NewJPanel
     *
     *
     */
    int[] netHealth = new int[6];
    int[] pcHealth = new int[6];
    int[] resultHealth = new int[6];

    

    public boolean launchToggled = false;

    public boolean pc1Toggled = false;
    public boolean pc2Toggled = false;
    public boolean pc3Toggled = false;
    public boolean pc4Toggled = false;
    public boolean pc5Toggled = false;
    public boolean pc6Toggled = false;

    public boolean net1Toggled = false;
    public boolean net2Toggled = false;
    public boolean net3Toggled = false;
    public boolean net4Toggled = false;
    public boolean net5Toggled = false;
    public boolean net6Toggled = false;

    public NewJPanel() {

        initComponents();

        for (int x = 0; x < 6; x++) {
            netHealth[x] = 0;
            pcHealth[x] = 0;
            resultHealth[x] = 0; ///change after
            
        }
        threadInstant();
    }
    public void threadInstant(){
        
       tokenH = new TokenHandler(this);
    }
    
    public void launchDoClick(){
        jToggleButton7.doClick();
        
    }
    public int nethealthCheck() {
        try {
            tokenH.sleep(500);
        } catch (InterruptedException e) {
            // Handle any potential InterruptedException
            e.printStackTrace();
        }
        for (int x = 0; x < 6; x++) {
            if (pcHealth[x] == 1 && netHealth[x] == 1) {
                resultHealth[x] = 1;
            }else if(pcHealth[x] == 0 && netHealth[x] == 1 ){
                
                
                //bypass:
                
                
                
                resultHealth[x] = 2;
                
                
            }
            
            
            else {
                resultHealth[x] = 0;
                             jToggleButton9.setForeground(Color.orange);
                             jToggleButton8.setForeground(Color.orange);
                             jToggleButton10.setForeground(Color.orange);
                             jToggleButton11.setForeground(Color.orange);
                             jToggleButton12.setForeground(Color.orange);
                             jToggleButton13.setForeground(Color.orange);
                             
         
                             
                             
                return 0;
            }
        }
        
         jToggleButton9.setForeground(Color.green);
                             jToggleButton8.setForeground(Color.green);
                             jToggleButton10.setForeground(Color.green);
                             jToggleButton11.setForeground(Color.green);
                             jToggleButton12.setForeground(Color.green);
                             jToggleButton13.setForeground(Color.green);
        return 1;

    }

    public void greenLit(int pos) {
        if (resultHealth[pos] == 1) {

            if (pos == 0) {

                jLabel7.setEnabled(true);
                jLabel8.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel12.setEnabled(false);
                
                label2.setText("FLOW: TOKEN NOW IS IN PC 1.");

            } else if (pos == 1) {

                jLabel8.setEnabled(true);
                jLabel7.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel12.setEnabled(false);
                label2.setText("FLOW: TOKEN NOW IS IN PC 2.");
            } else if (pos == 2) {

                jLabel9.setEnabled(true);
                jLabel8.setEnabled(false);
                jLabel7.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel12.setEnabled(false);
                label2.setText("FLOW: TOKEN NOW IS IN PC 3.");
            } else if (pos == 3) {

                jLabel10.setEnabled(true);
                jLabel8.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel7.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel12.setEnabled(false);
                label2.setText("FLOW: TOKEN NOW IS IN PC 4.");
            } else if (pos == 4) {

                jLabel11.setEnabled(true);
                jLabel8.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel7.setEnabled(false);
                jLabel12.setEnabled(false);
                label2.setText("FLOW: TOKEN NOW IS IN PC 5.");
            } else if (pos == 5) {

                jLabel12.setEnabled(true);
                jLabel8.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel7.setEnabled(false);
                label2.setText("FLOW: TOKEN NOW IS IN PC 6.");
            }

        }else if(resultHealth[pos] == 2){
             jLabel12.setEnabled(false);
                jLabel8.setEnabled(false);
                jLabel9.setEnabled(false);
                jLabel10.setEnabled(false);
                jLabel11.setEnabled(false);
                jLabel7.setEnabled(false);
                
                if(pos == 0){
                    label2.setText("BYPASS PC 1");
                  
                } else if(pos == 1){
                    label2.setText("BYPASS PC 2");
                    
                } else if(pos == 2){
                    label2.setText("BYPASS PC 3");
                   
                } else if(pos == 3){
                    label2.setText("BYPASS PC 4");
                    
                } else if(pos == 4){
                    label2.setText("BYPASS PC 5");
                    
                } else if(pos == 5){
                    label2.setText("BYPASS PC 6");
                    
                }   
        } 
        
        else {

            jLabel7.setEnabled(false);
            jLabel8.setEnabled(false);
            jLabel9.setEnabled(false);
            jLabel10.setEnabled(false);
            jLabel11.setEnabled(false);
            jLabel12.setEnabled(false);

        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();
        jToggleButton2 = new javax.swing.JToggleButton();
        jToggleButton3 = new javax.swing.JToggleButton();
        jToggleButton4 = new javax.swing.JToggleButton();
        jToggleButton5 = new javax.swing.JToggleButton();
        jToggleButton6 = new javax.swing.JToggleButton();
        jToggleButton7 = new javax.swing.JToggleButton();
        jToggleButton8 = new javax.swing.JToggleButton();
        jToggleButton9 = new javax.swing.JToggleButton();
        jToggleButton10 = new javax.swing.JToggleButton();
        jToggleButton11 = new javax.swing.JToggleButton();
        jToggleButton12 = new javax.swing.JToggleButton();
        jToggleButton13 = new javax.swing.JToggleButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        label1 = new java.awt.Label();
        label2 = new java.awt.Label();

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel1.setText("PC 1");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel2.setText("PC 2");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel3.setText("PC 3");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel4.setText("PC 4");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel5.setText("PC 5");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png"))); // NOI18N
        jLabel6.setText("PC 6");

        jToggleButton1.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton1.setLabel("ON / OFF");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jToggleButton2.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton2.setText("ON / OFF");
        jToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton2ActionPerformed(evt);
            }
        });

        jToggleButton3.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton3.setText("ON / OFF");
        jToggleButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton3ActionPerformed(evt);
            }
        });

        jToggleButton4.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton4.setText("ON / OFF");
        jToggleButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton4ActionPerformed(evt);
            }
        });

        jToggleButton5.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton5.setText("ON / OFF");
        jToggleButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton5ActionPerformed(evt);
            }
        });

        jToggleButton6.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton6.setText("ON / OFF");
        jToggleButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton6ActionPerformed(evt);
            }
        });

        jToggleButton7.setText("Launch Simulation");
        jToggleButton7.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jToggleButton7ItemStateChanged(evt);
            }
        });
        jToggleButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jToggleButton7MouseClicked(evt);
            }
        });
        jToggleButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton7ActionPerformed(evt);
            }
        });

        jToggleButton8.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton8.setText("CONNECT");
        jToggleButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton8ActionPerformed(evt);
            }
        });

        jToggleButton9.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton9.setText("CONNECT");
        jToggleButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton9ActionPerformed(evt);
            }
        });

        jToggleButton10.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton10.setText("CONNECT");
        jToggleButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton10ActionPerformed(evt);
            }
        });

        jToggleButton11.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton11.setText("CONNECT");
        jToggleButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton11ActionPerformed(evt);
            }
        });

        jToggleButton12.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton12.setText("CONNECT");
        jToggleButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton12ActionPerformed(evt);
            }
        });

        jToggleButton13.setForeground(new java.awt.Color(255, 51, 51));
        jToggleButton13.setText("CONNECT");
        jToggleButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton13ActionPerformed(evt);
            }
        });

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel7.setEnabled(false);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel8.setEnabled(false);

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel9.setEnabled(false);

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel10.setEnabled(false);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel11.setEnabled(false);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/token.png"))); // NOI18N
        jLabel12.setEnabled(false);

        label1.setAlignment(java.awt.Label.CENTER);
        label1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 51, 51));

        label2.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(198, 198, 198)
                        .addComponent(jLabel12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(198, 198, 198)
                        .addComponent(jLabel11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jToggleButton13)
                            .addComponent(jToggleButton6)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jToggleButton5)
                            .addComponent(jToggleButton12)))
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(jToggleButton1)
                                            .addComponent(jToggleButton9)
                                            .addComponent(jLabel7))
                                        .addGap(123, 123, 123))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jToggleButton11)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel10)
                                                .addGap(70, 70, 70)
                                                .addComponent(jLabel9))
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jToggleButton4))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jToggleButton10)
                            .addComponent(jLabel3)
                            .addComponent(jToggleButton3))
                        .addGap(52, 52, 52))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jToggleButton8)
                                    .addComponent(jToggleButton2))
                                .addGap(76, 76, 76))
                            .addComponent(jToggleButton7, javax.swing.GroupLayout.Alignment.TRAILING)))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jToggleButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jToggleButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel2)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jToggleButton8))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addComponent(jLabel8))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jToggleButton6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jToggleButton13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel12)))))
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel11)
                                .addGap(1, 1, 1)
                                .addComponent(jToggleButton12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jToggleButton5))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jToggleButton10)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jToggleButton3)
                                .addGap(40, 40, 40)))
                        .addGap(66, 66, 66)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jToggleButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jToggleButton4)
                        .addGap(53, 53, 53))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed

        // TODO add your handling code here:if (toggled) {
        if (pc1Toggled) {

            pc1Toggled = false;
            pcHealth[0] = 0;
            jToggleButton1.setForeground(Color.red);
            jToggleButton1.setText("TURN ON");
            jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc1Toggled = true;
            pcHealth[0] = 1;
            jToggleButton1.setForeground(Color.green);
            jToggleButton1.setText("TURN OFF");
            jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/2222.png")));
        }

    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jToggleButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jToggleButton7MouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_jToggleButton7MouseClicked

    private void jToggleButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton7ActionPerformed
        // TODO add your handling code here:
        if (launchToggled) {
            label1.setForeground(Color.red);
            label1.setText("CONNECTION BROKEN...");
 //           tokenH.interrupt();
            threadInstant();
            
            launchToggled = false;
            jToggleButton7.setText("Launch Simulation");

        } else {
            
            if(nethealthCheck() == 0){
                
                launchToggled = false;
                jToggleButton7.setText("RESET");
                label1.setForeground(Color.red);
                label1.setText("TOKEN ROTATION FAILURE...");
                label2.setForeground(Color.red);
                label2.setText("Please make sure  all"
                        + " Computers are established and"
                        + " connected..");
                
                
            }

            else{
  
                tokenH.start();
                launchToggled = true;
                jToggleButton7.setText("Stop Simulation");
                label1.setForeground(Color.blue);
                label1.setText("TOKEN STATUS: OK");
                label2.setForeground(Color.blue);
 
            }
        }
    }//GEN-LAST:event_jToggleButton7ActionPerformed

    private void jToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton2ActionPerformed
        if (pc2Toggled) {

            pc2Toggled = false;
            pcHealth[1] = 0;
            jToggleButton2.setForeground(Color.red);
            jToggleButton2.setText("TURN ON");
            jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc2Toggled = true;
            pcHealth[1] = 1;
            jToggleButton2.setForeground(Color.green);
            jToggleButton2.setText("TURN OFF");
            jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/9999.png")));
            
            // Add action to perform when button is toggled on
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton2ActionPerformed

    private void jToggleButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton3ActionPerformed
        if (pc3Toggled) {

            pc3Toggled = false;
            pcHealth[2] = 0;
            jToggleButton3.setForeground(Color.red);
            jToggleButton3.setText("TURN ON");
            jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc3Toggled = true;
            pcHealth[2] = 1;
            jToggleButton3.setForeground(Color.green);
            jToggleButton3.setText("TURN OFF");
            jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/777.png")));
            
            // Add action to perform when button is toggled on
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton3ActionPerformed

    private void jToggleButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton4ActionPerformed
        if (pc4Toggled) {

            pc4Toggled = false;
            pcHealth[3] = 0;
            jToggleButton4.setForeground(Color.red);
            jToggleButton4.setText("TURN ON");
            jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc4Toggled = true;
            pcHealth[3] = 1;
            jToggleButton4.setForeground(Color.green);
            jToggleButton4.setText("TURN OFF");
            jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/5555.png")));
            
            // Add action to perform when button is toggled on
        }        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton4ActionPerformed

    private void jToggleButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton5ActionPerformed
        if (pc5Toggled) {

            pc5Toggled = false;
            pcHealth[4] = 0;
            jToggleButton5.setForeground(Color.red);
            jToggleButton5.setText("TURN ON");
            jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc5Toggled = true;
            pcHealth[4] = 1;
             jToggleButton5.setForeground(Color.green);
            jToggleButton5.setText("TURN OFF");
            jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/4444.png")));
           
            // Add action to perform when button is toggled on
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton5ActionPerformed

    private void jToggleButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton6ActionPerformed
        if (pc6Toggled) {

            pc6Toggled = false;
            pcHealth[5] = 0;
            jToggleButton6.setForeground(Color.red);
            jToggleButton6.setText("TURN ON");
             jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/pc_node.png")));
            // Add action to perform when button is toggled off
        } else {
            pc6Toggled = true;
            pcHealth[5] = 1;
            jToggleButton6.setForeground(Color.green);
            jToggleButton6.setText("TURN OFF");
            jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ringtopologyproject/res/888.png")));
            
            // Add action to perform when button is toggled on
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton6ActionPerformed

    private void jToggleButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton9ActionPerformed
        if (net1Toggled) {

            net1Toggled = false;
            netHealth[0] = 0;
            jToggleButton9.setForeground(Color.red);
            jToggleButton9.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net1Toggled = true;
            netHealth[0] = 1;
            jToggleButton9.setText("BREAK");
            jToggleButton9.setForeground(Color.green);
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton9ActionPerformed

    private void jToggleButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton8ActionPerformed
        if (net2Toggled) {

            net2Toggled = false;
            netHealth[1] = 0;
             jToggleButton8.setForeground(Color.red);
            jToggleButton8.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net2Toggled = true;
            netHealth[1] = 1;
            jToggleButton8.setText("BREAK");
            jToggleButton8.setForeground(Color.green);
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton8ActionPerformed

    private void jToggleButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton10ActionPerformed
        if (net3Toggled) {

            net3Toggled = false;
            netHealth[2] = 0;
             jToggleButton10.setForeground(Color.red);
            jToggleButton10.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net3Toggled = true;
            netHealth[2] = 1;
            jToggleButton10.setText("BREAK");
            jToggleButton10.setForeground(Color.green);
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton10ActionPerformed

    private void jToggleButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton11ActionPerformed
        if (net4Toggled) {

            net4Toggled = false;
            netHealth[3] = 0;
             jToggleButton11.setForeground(Color.red);
            jToggleButton11.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net4Toggled = true;
            netHealth[3] = 1;
            jToggleButton11.setText("BREAK");
            jToggleButton11.setForeground(Color.green);
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton11ActionPerformed

    private void jToggleButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton12ActionPerformed
        if (net5Toggled) {

            net5Toggled = false;
            netHealth[4] = 0;
             jToggleButton12.setForeground(Color.red);
            jToggleButton12.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net5Toggled = true;
            netHealth[4] = 1;
            jToggleButton12.setForeground(Color.green);
            jToggleButton12.setText("BREAK");
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton12ActionPerformed

    private void jToggleButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton13ActionPerformed
        if (net6Toggled) {

            net6Toggled = false;
            netHealth[5] = 0;
            jToggleButton13.setForeground(Color.red);
            jToggleButton13.setText("RECONNECT");
            // Add action to perform when button is toggled off
        } else {
            net6Toggled = true;
            netHealth[5] = 1;
            jToggleButton13.setForeground(Color.green);
            jToggleButton13.setText("BREAK");
            // Add action to perform when button is toggled on
        }          // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton13ActionPerformed

    private void jToggleButton7ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jToggleButton7ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jToggleButton7ItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JToggleButton jToggleButton10;
    private javax.swing.JToggleButton jToggleButton11;
    private javax.swing.JToggleButton jToggleButton12;
    private javax.swing.JToggleButton jToggleButton13;
    private javax.swing.JToggleButton jToggleButton2;
    private javax.swing.JToggleButton jToggleButton3;
    private javax.swing.JToggleButton jToggleButton4;
    private javax.swing.JToggleButton jToggleButton5;
    private javax.swing.JToggleButton jToggleButton6;
    private javax.swing.JToggleButton jToggleButton7;
    private javax.swing.JToggleButton jToggleButton8;
    private javax.swing.JToggleButton jToggleButton9;
    private java.awt.Label label1;
    private java.awt.Label label2;
    // End of variables declaration//GEN-END:variables
}
