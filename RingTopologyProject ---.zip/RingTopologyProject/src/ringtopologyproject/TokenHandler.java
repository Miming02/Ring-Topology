/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ringtopologyproject;

/**
 *
 * @author user
 */
public class TokenHandler extends Thread {

    public NewJPanel jpanel;

    public TokenHandler(NewJPanel jpn) {

        this.jpanel = jpn;

    }

    @Override
    public void run() {
        int x = 0;
        while (jpanel.launchToggled) {
            if (jpanel.nethealthCheck() == 1) {

                jpanel.greenLit(x);

            } else {
                jpanel.launchDoClick();
            }

            if (x == 5) {
                x = 0;
            } else {
                x++;
            };
        }

    }
}
